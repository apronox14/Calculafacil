---
name: Date-only timezone handling
description: Safe parsing and comparison of date-only form values in the Spain-focused calculators.
---

Validate `YYYY-MM-DD` values by comparing their numeric year, month, and day in UTC. Do not parse a local midnight and validate it with `toISOString()`, which can shift the calendar date.

**Why:** Europe/Berlin local midnight can fall on the previous UTC date, making a valid birth date appear invalid.

**How to apply:** Keep date-only arithmetic separate from timestamps and test date forms with `TZ=Europe/Berlin`.
