import { useEffect, useMemo, useState } from "react";
import {
  Link,
  Route,
  Switch,
  useLocation,
  Router as WouterRouter,
} from "wouter";
import { ErrorBoundary } from "@/components/error-boundary";
import { baseValues, calculate, type Values } from "@/lib/calculations";

type Tool = {
  path: string;
  title: string;
  short: string;
  category: string;
  description: string;
  icon: string;
  added?: boolean;
};
const tools: Tool[] = [
  {
    path: "/calculadora-porcentajes",
    title: "Calculadora de porcentajes",
    short: "Calcula porcentajes y diferencias",
    category: "Finanzas",
    description:
      "Calcula un porcentaje de una cantidad o compara dos valores con claridad.",
    icon: "%",
  },
  {
    path: "/calculadora-iva",
    title: "Calculadora de IVA",
    short: "Añade o quita el IVA",
    category: "Finanzas",
    description:
      "Obtén el precio con IVA o la base imponible con los tipos habituales en España.",
    icon: "IVA",
  },
  {
    path: "/calculadora-descuentos",
    title: "Calculadora de descuentos",
    short: "Precio final y ahorro",
    category: "Compras",
    description: "Descubre cuánto pagas y cuánto ahorras con una rebaja.",
    icon: "−%",
  },
  {
    path: "/calculadora-edad",
    title: "Calculadora de edad",
    short: "Edad exacta y próximo cumpleaños",
    category: "Fecha y tiempo",
    description:
      "Conoce tu edad exacta en años, meses y días y cuándo será tu próximo cumpleaños.",
    icon: "ED",
  },
  {
    path: "/regla-de-tres",
    title: "Regla de tres",
    short: "Resuelve proporciones fácilmente",
    category: "Matemáticas",
    description:
      "Completa una proporción directa indicando el valor que falta.",
    icon: "a:b",
  },
  {
    path: "/dias-entre-fechas",
    title: "Días entre fechas",
    short: "Cuenta días entre dos fechas",
    category: "Fecha y tiempo",
    description:
      "Calcula la diferencia exacta entre dos fechas, con opción inclusiva.",
    icon: "DÍAS",
  },
  {
    path: "/convertir-kilometros-a-millas",
    title: "Kilómetros a millas",
    short: "Conversor km ↔ mi",
    category: "Conversiones",
    description:
      "Convierte kilómetros a millas y millas a kilómetros al instante.",
    icon: "km",
  },
  {
    path: "/convertir-kilos-a-libras",
    title: "Kilos a libras",
    short: "Conversor kg ↔ lb",
    category: "Conversiones",
    description: "Convierte kilogramos a libras o libras a kilogramos.",
    icon: "kg",
  },
  {
    path: "/calculadora-propinas",
    title: "Calculadora de propinas",
    short: "Reparte la cuenta entre varias personas",
    category: "Finanzas",
    description:
      "Calcula una propina y reparte el total de la cuenta por persona.",
    icon: "€",
  },
  {
    path: "/calculadora-ahorro-mensual",
    title: "Calculadora de ahorro mensual",
    short: "Estima cuánto puedes ahorrar",
    category: "Finanzas",
    description:
      "Proyecta tu ahorro a lo largo del tiempo con aportaciones e interés mensual compuesto.",
    icon: "+",
    added: true,
  },
];
const legalPages = [
  {
    path: "/politica-de-privacidad",
    title: "Política de privacidad",
    description:
      "Consulta esta plantilla editable sobre el tratamiento de datos personales en CalculaFácil.",
  },
  {
    path: "/politica-de-cookies",
    title: "Política de cookies",
    description:
      "Información editable sobre cookies y preferencias de privacidad de CalculaFácil.",
  },
  {
    path: "/aviso-legal",
    title: "Aviso legal",
    description:
      "Plantilla editable de aviso legal para el portal CalculaFácil.",
  },
  {
    path: "/contacto",
    title: "Contacto",
    description:
      "Ponte en contacto con el equipo de CalculaFácil mediante un mensaje de correo electrónico.",
  },
  {
    path: "/sobre-nosotros",
    title: "Sobre nosotros",
    description:
      "Conoce el propósito de CalculaFácil: respuestas prácticas, claras y gratuitas.",
  },
];
const faqs = [
  {
    q: "¿Las calculadoras de CalculaFácil son gratuitas?",
    a: "Sí. Puedes usar todas las herramientas sin registro y sin pagar. Los cálculos se realizan directamente en tu navegador.",
  },
  {
    q: "¿Se guardan los números que introduzco?",
    a: "Los valores de las calculadoras no se envían a un servidor. La preferencia de cookies se guarda localmente en este dispositivo.",
  },
  {
    q: "¿Puedo usar las herramientas desde el móvil?",
    a: "Sí. La página se adapta a pantallas pequeñas y los campos se pueden manejar con teclado o pantalla táctil.",
  },
];
const pageFaqs: Record<string, { q: string; a: string }[]> = {
  "/calculadora-porcentajes": [
    {
      q: "¿Cómo se calcula un porcentaje de una cantidad?",
      a: "Multiplica la cantidad por el porcentaje y divide el resultado entre 100. Por ejemplo, el 15 % de 80 es 12.",
    },
    {
      q: "¿Cómo se calcula la diferencia porcentual?",
      a: "Se compara el cambio con el valor inicial: (valor nuevo − valor inicial) ÷ valor inicial × 100. El signo indica si sube o baja.",
    },
  ],
  "/calculadora-iva": [
    {
      q: "¿Qué tipos de IVA puedo calcular?",
      a: "La herramienta incluye los tipos generales del 21 %, reducido del 10 % y superreducido del 4 %. Comprueba qué tipo corresponde a cada producto o servicio.",
    },
    {
      q: "¿Cómo se obtiene la base imponible al quitar el IVA?",
      a: "Divide el precio con IVA entre 1 más el tipo expresado en decimal. No se debe restar simplemente el porcentaje del precio final.",
    },
  ],
  "/calculadora-descuentos": [
    {
      q: "¿Cómo se calcula el precio tras un descuento?",
      a: "Multiplica el precio original por (1 − descuento/100). La diferencia con el precio inicial es el ahorro.",
    },
  ],
  "/calculadora-edad": [
    {
      q: "¿Cómo se calcula la edad exacta?",
      a: "Se comparan año, mes y día de nacimiento con la fecha de hoy, teniendo en cuenta si el cumpleaños de este año ya ha pasado.",
    },
  ],
  "/regla-de-tres": [
    {
      q: "¿Qué es una regla de tres directa?",
      a: "Es una proporción en la que al aumentar una magnitud, la otra cambia en la misma proporción. El valor desconocido se obtiene multiplicando en cruz y dividiendo.",
    },
  ],
  "/dias-entre-fechas": [
    {
      q: "¿El resultado incluye el día inicial?",
      a: "Por defecto se muestra la diferencia de días transcurridos, sin contar dos veces el día inicial. Puedes activar el modo inclusivo para contar ambos extremos.",
    },
  ],
  "/convertir-kilometros-a-millas": [
    {
      q: "¿Cuál es el factor de conversión?",
      a: "Una milla internacional equivale exactamente a 1,609344 kilómetros. El conversor usa ese factor en ambas direcciones.",
    },
  ],
  "/convertir-kilos-a-libras": [
    {
      q: "¿Cuántas libras tiene un kilogramo?",
      a: "Un kilogramo equivale aproximadamente a 2,20462262 libras. El resultado se redondea a dos decimales para facilitar la lectura.",
    },
  ],
  "/calculadora-propinas": [
    {
      q: "¿Cómo se reparte la propina?",
      a: "La propina se calcula sobre el importe de la cuenta y se suma al total. Después, el total y la parte de propina se dividen entre el número de personas.",
    },
  ],
  "/calculadora-ahorro-mensual": [
    {
      q: "¿Qué supone el interés compuesto mensual?",
      a: "La estimación convierte el tipo anual nominal en un tipo mensual (anual dividido entre 12) y aplica el interés cada mes, después de cada aportación.",
    },
  ],
};
const routeInfo: Record<string, { title: string; desc: string }> = {
  "/": {
    title: "Calculadoras gratuitas online | CalculaFácil",
    desc: "Calcula, convierte y descubre resultados fácilmente con herramientas gratuitas, claras y rápidas. Sin registros y sin pagar.",
  },
  ...Object.fromEntries(
    tools.map((t) => [
      t.path,
      {
        title: `${t.title} online gratis | CalculaFácil`,
        desc: `${t.description} Usa ${t.title.toLowerCase()} gratis, sin registro y con resultados inmediatos.`,
      },
    ]),
  ),
  ...Object.fromEntries(
    legalPages.map((p) => [
      p.path,
      { title: `${p.title} | CalculaFácil`, desc: p.description },
    ]),
  ),
};
const categories = [
  "Todas",
  "Finanzas",
  "Compras",
  "Fecha y tiempo",
  "Matemáticas",
  "Conversiones",
];
const euro = (n: number) =>
  new Intl.NumberFormat("es-ES", {
    style: "currency",
    currency: "EUR",
    maximumFractionDigits: 2,
  }).format(n);
const number = (n: number, digits = 2) =>
  new Intl.NumberFormat("es-ES", { maximumFractionDigits: digits }).format(n);
const todayISO = () => {
  const d = new Date();
  return `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, "0")}-${String(d.getDate()).padStart(2, "0")}`;
};

function Seo({
  path,
  faq,
}: {
  path: string;
  faq?: { q: string; a: string }[];
}) {
  useEffect(() => {
    const info = routeInfo[path] ?? routeInfo["/"];
    document.title = info.title;
    const setMeta = (selector: string, attr: string, value: string) => {
      let el = document.head.querySelector(selector) as HTMLMetaElement | null;
      if (!el) {
        el = document.createElement("meta");
        document.head.appendChild(el);
      }
      el.setAttribute(attr, value);
    };
    setMeta('meta[name="description"]', "content", info.desc);
    setMeta('meta[property="og:title"]', "content", info.title);
    setMeta('meta[property="og:description"]', "content", info.desc);
    const configured = (
      import.meta.env.VITE_SITE_URL as string | undefined
    )?.replace(/\/$/, "");
    const canonicalUrl = `${configured || window.location.origin}${path === "/" ? "/" : path}`;
    setMeta('meta[property="og:url"]', "content", canonicalUrl);
    setMeta('meta[property="og:type"]', "content", "website");
    setMeta('meta[name="twitter:card"]', "content", "summary");
    setMeta('meta[name="twitter:title"]', "content", info.title);
    setMeta('meta[name="twitter:description"]', "content", info.desc);
    let canonical = document.head.querySelector(
      'link[rel="canonical"]',
    ) as HTMLLinkElement | null;
    if (!canonical) {
      canonical = document.createElement("link");
      canonical.rel = "canonical";
      document.head.appendChild(canonical);
    }
    canonical.href = canonicalUrl;
    const scripts = document.querySelectorAll(
      "script[data-calculafacil-schema]",
    );
    scripts.forEach((s) => s.remove());
    const schemas: unknown[] = [
      {
        "@context": "https://schema.org",
        "@type": "WebSite",
        name: "CalculaFácil",
        url: `${configured || window.location.origin}/`,
        inLanguage: "es-ES",
      },
      {
        "@context": "https://schema.org",
        "@type": "WebApplication",
        name: "CalculaFácil",
        applicationCategory: "UtilitiesApplication",
        operatingSystem: "Any",
        description: info.desc,
        url: `${configured || window.location.origin}${path}`,
      },
    ];
    if (path !== "/")
      schemas.push({
        "@context": "https://schema.org",
        "@type": "BreadcrumbList",
        itemListElement: [
          {
            "@type": "ListItem",
            position: 1,
            name: "Inicio",
            item: `${configured || window.location.origin}/`,
          },
          {
            "@type": "ListItem",
            position: 2,
            name:
              tools.find((t) => t.path === path)?.title ||
              legalPages.find((p) => p.path === path)?.title ||
              "Página",
            item: `${configured || window.location.origin}${path}`,
          },
        ],
      });
    if (faq?.length)
      schemas.push({
        "@context": "https://schema.org",
        "@type": "FAQPage",
        mainEntity: faq.map((x) => ({
          "@type": "Question",
          name: x.q,
          acceptedAnswer: { "@type": "Answer", text: x.a },
        })),
      });
    schemas.forEach((value) => {
      const s = document.createElement("script");
      s.type = "application/ld+json";
      s.dataset.calculafacilSchema = "true";
      s.textContent = JSON.stringify(value);
      document.head.appendChild(s);
    });
  }, [path, faq]);
  return null;
}

function SiteHeader() {
  return (
    <header className="topbar">
      <div className="container nav-wrap">
        <Link href="/" className="brand" data-testid="link-brand">
          <span className="brand-mark">C</span>
          <span>CalculaFácil</span>
        </Link>
        <nav className="nav-links" aria-label="Navegación principal">
          <Link href="/" data-testid="link-nav-inicio">
            Inicio
          </Link>
          <a href="/#calculadoras" data-testid="link-nav-calculadoras">
            Calculadoras
          </a>
          <Link href="/sobre-nosotros" data-testid="link-nav-nosotros">
            Sobre nosotros
          </Link>
        </nav>
        <Link
          className="header-cta"
          href="/contacto"
          data-testid="link-nav-contacto"
        >
          Contacto <span aria-hidden="true">→</span>
        </Link>
      </div>
      <nav className="container mobile-nav" aria-label="Navegación móvil">
        <Link href="/" data-testid="link-mobile-inicio">
          Inicio
        </Link>
        <a href="/#calculadoras" data-testid="link-mobile-calculadoras">
          Calculadoras
        </a>
        <Link href="/sobre-nosotros" data-testid="link-mobile-nosotros">
          Sobre nosotros
        </Link>
        <Link href="/contacto" data-testid="link-mobile-contacto">
          Contacto
        </Link>
      </nav>
    </header>
  );
}
function AdSlot({ compact = false }: { compact?: boolean }) {
  return (
    <aside
      className="ad-slot"
      aria-label="Espacio reservado para publicidad"
      data-testid="ad-slot-reservado"
    >
      <div>
        Espacio reservado para publicidad
        <span>
          {compact
            ? "Anuncio reservado"
            : "Sin anuncios activos · espacio publicitario reservado"}
        </span>
      </div>
    </aside>
  );
}
function Footer({ onCookie }: { onCookie: () => void }) {
  return (
    <footer className="footer">
      <div className="container">
        <div className="footer-grid">
          <div>
            <Link href="/" className="brand" data-testid="link-footer-brand">
              <span className="brand-mark">C</span>
              <span style={{ color: "#fff" }}>CalculaFácil</span>
            </Link>
            <p style={{ maxWidth: 350, marginTop: 16 }}>
              Respuestas útiles para el día a día. Herramientas gratuitas,
              fáciles de usar y sin registro.
            </p>
          </div>
          <div>
            <h3>Calculadoras</h3>
            <div className="footer-links">
              {tools.map((t) => (
                <Link
                  key={t.path}
                  href={t.path}
                  data-testid={`link-footer-${t.path.slice(1)}`}
                >
                  {t.title}
                </Link>
              ))}
            </div>
          </div>
          <div>
            <h3>Información</h3>
            <div className="footer-links">
              {legalPages.map((p) => (
                <Link
                  key={p.path}
                  href={p.path}
                  data-testid={`link-footer-${p.path.slice(1)}`}
                >
                  {p.title}
                </Link>
              ))}
              <button
                onClick={onCookie}
                className="text-link"
                style={{
                  textAlign: "left",
                  background: "none",
                  border: 0,
                  padding: 0,
                  cursor: "pointer",
                }}
                data-testid="button-footer-cookies"
              >
                Preferencias de cookies
              </button>
            </div>
          </div>
        </div>
        <div className="footer-bottom">
          <span>
            © {new Date().getFullYear()} CalculaFácil. Herramientas útiles, sin
            complicaciones.
          </span>
          <span>Hecho para responder claro.</span>
        </div>
      </div>
    </footer>
  );
}
function readCookieChoice() {
  const defaults = {
    necessary: true,
    analytics: false,
    personalization: false,
    advertising: false,
  };
  try {
    const stored = localStorage.getItem("calculafacil-cookie-choice");
    if (!stored) return { choice: defaults, saved: false };
    const parsed = JSON.parse(stored);
    return {
      choice: {
        necessary: true,
        analytics: parsed.analytics === true,
        personalization: parsed.personalization === true,
        advertising: parsed.advertising === true,
      },
      saved: true,
    };
  } catch {
    return { choice: defaults, saved: false };
  }
}
function CookiePreferences({
  open,
  onClose,
}: {
  open: boolean;
  onClose: () => void;
}) {
  const [initial] = useState(readCookieChoice);
  const [choice, setChoice] = useState(initial.choice);
  const [saved, setSaved] = useState(initial.saved);
  const [custom, setCustom] = useState(false);
  const persist = (value: {
    necessary: boolean;
    analytics: boolean;
    personalization: boolean;
    advertising: boolean;
  }) => {
    try {
      localStorage.setItem("calculafacil-cookie-choice", JSON.stringify(value));
    } catch {}
    setChoice(value);
    setSaved(true);
    setCustom(false);
    onClose();
  };
  if (saved && !open) return null;
  return (
    <section
      className="cookie-banner"
      role="dialog"
      aria-label="Preferencias de cookies"
      aria-modal="false"
      data-testid="panel-cookies"
    >
      <div style={{ flex: 1 }}>
        <h2>Tu privacidad, a tu manera</h2>
        <p>
          Usamos almacenamiento local imprescindible para recordar tu elección.
          No cargamos analítica ni publicidad de terceros. Puedes cambiar tus
          preferencias cuando quieras.
        </p>
        {custom && (
          <div
            style={{ display: "flex", gap: 18, marginTop: 12, fontSize: 13 }}
          >
            <label>
              <input
                type="checkbox"
                checked
                disabled
                data-testid="input-cookie-necesarias"
              />{" "}
              Necesarias
            </label>
            <label>
              <input
                type="checkbox"
                checked={choice.analytics}
                onChange={(e) =>
                  setChoice({ ...choice, analytics: e.target.checked })
                }
                data-testid="input-cookie-analitica"
              />{" "}
              Analítica opcional
            </label>
            <label>
              <input
                type="checkbox"
                checked={choice.personalization}
                onChange={(e) =>
                  setChoice({ ...choice, personalization: e.target.checked })
                }
                data-testid="input-cookie-personalizacion"
              />{" "}
              Personalización opcional
            </label>
            <label>
              <input
                type="checkbox"
                checked={choice.advertising}
                onChange={(e) =>
                  setChoice({ ...choice, advertising: e.target.checked })
                }
                data-testid="input-cookie-publicidad"
              />{" "}
              Publicidad opcional
            </label>
          </div>
        )}
      </div>
      <div className="cookie-actions">
        <button
          className="button secondary"
          onClick={() =>
            persist({
              necessary: true,
              analytics: false,
              personalization: false,
              advertising: false,
            })
          }
          data-testid="button-cookies-rechazar"
        >
          Rechazar opcionales
        </button>
        <button
          className="button secondary"
          onClick={() => {
            if (custom) persist(choice);
            else setCustom(true);
          }}
          data-testid="button-cookies-personalizar"
        >
          {custom ? "Guardar selección" : "Personalizar"}
        </button>
        <button
          className="button"
          onClick={() =>
            persist({
              necessary: true,
              analytics: true,
              personalization: true,
              advertising: true,
            })
          }
          data-testid="button-cookies-aceptar"
        >
          Aceptar todas
        </button>
      </div>
    </section>
  );
}
function Shell({
  children,
  path,
}: {
  children: React.ReactNode;
  path: string;
}) {
  const [cookieOpen, setCookieOpen] = useState(false);
  return (
    <div className="site">
      <Seo path={path} faq={path === "/" ? faqs : pageFaqs[path]} />
      <SiteHeader />
      {children}
      <Footer onCookie={() => setCookieOpen(true)} />
      <CookiePreferences
        open={cookieOpen}
        onClose={() => setCookieOpen(false)}
      />
    </div>
  );
}
function ToolCard({ tool }: { tool: Tool }) {
  return (
    <Link
      className="tool-card"
      href={tool.path}
      data-testid={`link-tool-${tool.path.slice(1)}`}
    >
      <span className="tool-icon" aria-hidden="true">
        {tool.icon}
      </span>
      <h3>
        {tool.title}
        {tool.added && (
          <span
            style={{
              fontSize: 10,
              color: "#27775f",
              marginLeft: 8,
              fontFamily: "DM Sans",
            }}
          >
            NUEVA
          </span>
        )}
      </h3>
      <p>{tool.short}</p>
    </Link>
  );
}
function Faq({ items }: { items: { q: string; a: string }[] }) {
  return (
    <section className="section" style={{ paddingTop: 25 }}>
      <div
        className="container"
        style={{
          maxWidth: 800,
          marginLeft: "max(20px,calc((100% - 1120px)/2))",
        }}
      >
        <h2 style={{ fontSize: 25, marginBottom: 20 }}>Preguntas frecuentes</h2>
        <div className="faq-list">
          {items.map((f, i) => (
            <article className="faq-item" key={f.q}>
              <h3>{f.q}</h3>
              <p data-testid={`text-faq-answer-${i}`}>{f.a}</p>
            </article>
          ))}
        </div>
      </div>
    </section>
  );
}
function Home() {
  const [search, setSearch] = useState("");
  const [category, setCategory] = useState("Todas");
  const visible = useMemo(
    () =>
      tools.filter(
        (t) =>
          (category === "Todas" || t.category === category) &&
          `${t.title} ${t.short} ${t.category}`
            .toLowerCase()
            .includes(search.trim().toLowerCase()),
      ),
    [category, search],
  );
  return (
    <Shell path="/">
      <main>
        <section className="hero">
          <div className="container hero-inner">
            <span className="eyebrow">
              Herramientas prácticas, siempre a mano
            </span>
            <h1>Todas tus calculadoras gratuitas en un solo lugar</h1>
            <p>
              Calcula, convierte y descubre resultados fácilmente, sin registros
              y sin pagar
            </p>
            <label className="searchbox">
              <span className="search-icon" aria-hidden="true">
                ⌕
              </span>
              <span className="sr-only">Buscar calculadora</span>
              <input
                type="search"
                value={search}
                onChange={(e) => setSearch(e.target.value)}
                placeholder="¿Qué necesitas calcular?"
                data-testid="input-buscar-calculadoras"
              />
            </label>
            <div className="hero-note">
              Sin cuentas. Sin coste. El resultado, al instante.
            </div>
          </div>
        </section>
        <AdSlot />
        <section
          id="calculadoras"
          className="section"
          style={{ paddingTop: 24 }}
        >
          <div className="container">
            <div className="section-head">
              <div>
                <span className="eyebrow">Encuentra tu herramienta</span>
                <h2 style={{ marginTop: 11 }}>Calculadoras para cada día</h2>
                <p className="section-intro">
                  Elige una categoría o busca directamente lo que necesitas.
                </p>
              </div>
            </div>
            <nav
              className="category-row"
              aria-label="Categorías de calculadoras"
            >
              {categories.map((c) => (
                <button
                  key={c}
                  className={`chip ${category === c ? "active" : ""}`}
                  onClick={() => setCategory(c)}
                  aria-pressed={category === c}
                  data-testid={`button-category-${c.toLowerCase().replaceAll(" ", "-")}`}
                >
                  {c}
                </button>
              ))}
            </nav>
            {visible.length ? (
              <div className="tool-grid">
                {visible.map((t) => (
                  <ToolCard key={t.path} tool={t} />
                ))}
              </div>
            ) : (
              <div
                className="no-results"
                role="status"
                data-testid="status-sin-resultados"
              >
                <strong>No encontramos calculadoras con “{search}”.</strong>
                <p style={{ margin: "8px 0 0" }}>
                  Prueba con otra palabra o cambia la categoría seleccionada.
                </p>
                <button
                  className="button secondary"
                  style={{ marginTop: 15 }}
                  onClick={() => {
                    setSearch("");
                    setCategory("Todas");
                  }}
                  data-testid="button-limpiar-busqueda"
                >
                  Ver todas las calculadoras
                </button>
              </div>
            )}
          </div>
        </section>
        <section className="section" style={{ background: "#edf4f7" }}>
          <div className="container">
            <div className="section-head">
              <div>
                <span className="eyebrow">A mano cuando hace falta</span>
                <h2 style={{ marginTop: 11 }}>Las más populares</h2>
                <p className="section-intro">
                  Herramientas para compras, cuentas y decisiones cotidianas.
                </p>
              </div>
            </div>
            <div className="tool-grid">
              {[tools[0], tools[1], tools[2], tools[8], tools[3], tools[5]].map(
                (t) => (
                  <ToolCard key={t.path} tool={t} />
                ),
              )}
            </div>
          </div>
        </section>
        <AdSlot />
        <section className="section">
          <div className="container">
            <div className="section-head">
              <div>
                <span className="eyebrow">Recién incorporada</span>
                <h2 style={{ marginTop: 11 }}>Más claridad para tus planes</h2>
                <p className="section-intro">
                  Una nueva forma de visualizar el efecto de ahorrar mes a mes.
                </p>
              </div>
            </div>
            <div style={{ maxWidth: 560 }}>
              <ToolCard tool={tools[9]} />
            </div>
          </div>
        </section>
        <Faq items={faqs} />
        <section className="section" style={{ paddingTop: 5 }}>
          <div className="container" style={{ maxWidth: 800 }}>
            <h2 style={{ fontSize: 25 }}>
              Un resultado claro, sin pasos de más
            </h2>
            <p className="article-copy">
              CalculaFácil reúne herramientas sencillas para resolver pequeñas
              dudas del día a día: cuánto supone un descuento, cuántos días
              faltan para una fecha o cómo se reparte una cuenta. Introduce tus
              datos y el resultado se actualiza mientras escribes.
            </p>
          </div>
        </section>
      </main>
    </Shell>
  );
}

function InputField({
  label,
  name,
  value,
  onChange,
  type = "number",
  min = "0",
  step = "any",
  children,
  help,
}: {
  label: string;
  name: string;
  value: string;
  onChange: (name: string, value: string) => void;
  type?: string;
  min?: string;
  step?: string;
  children?: React.ReactNode;
  help?: string;
}) {
  return (
    <div className="field">
      <label htmlFor={`field-${name}`}>{label}</label>
      {children ?? (
        <input
          id={`field-${name}`}
          type={type}
          min={type === "number" ? min : undefined}
          step={type === "number" ? step : undefined}
          value={value}
          onChange={(e) => onChange(name, e.target.value)}
          data-testid={`input-${name}`}
        />
      )}
      {help && <span className="help">{help}</span>}
    </div>
  );
}
function SelectField({
  label,
  name,
  value,
  options,
  onChange,
}: {
  label: string;
  name: string;
  value: string;
  options: [string, string][];
  onChange: (name: string, value: string) => void;
}) {
  return (
    <div className="field">
      <label htmlFor={`field-${name}`}>{label}</label>
      <select
        id={`field-${name}`}
        value={value}
        onChange={(e) => onChange(name, e.target.value)}
        data-testid={`select-${name}`}
      >
        {options.map(([v, t]) => (
          <option key={v} value={v}>
            {t}
          </option>
        ))}
      </select>
    </div>
  );
}

function CalculatorFields({
  path,
  v,
  onChange,
}: {
  path: string;
  v: Values;
  onChange: (k: string, val: string) => void;
}) {
  const field = (
    label: string,
    name: string,
    opts: Partial<Parameters<typeof InputField>[0]> = {},
  ) => (
    <InputField
      key={name}
      label={label}
      name={name}
      value={v[name] ?? ""}
      onChange={onChange}
      {...opts}
    />
  );
  if (path === "/calculadora-porcentajes")
    return (
      <>
        <SelectField
          label="¿Qué quieres calcular?"
          name="mode"
          value={v.mode}
          onChange={onChange}
          options={[
            ["amount", "Porcentaje de una cantidad"],
            ["difference", "Diferencia porcentual entre dos valores"],
          ]}
        />
        {v.mode === "amount" ? (
          <>
            {field("Cantidad", "amount")}
            {field("Porcentaje", "percent")}
          </>
        ) : (
          <>
            {field("Valor inicial", "from")}
            {field("Valor final", "to")}
          </>
        )}
      </>
    );
  if (path === "/calculadora-iva")
    return (
      <>
        <SelectField
          label="Operación"
          name="mode"
          value={v.mode}
          onChange={onChange}
          options={[
            ["add", "Añadir IVA al precio"],
            ["remove", "Quitar IVA del precio"],
          ]}
        />
        {field(
          v.mode === "add" ? "Precio sin IVA" : "Precio con IVA",
          "amount",
        )}
        <SelectField
          label="Tipo de IVA"
          name="rate"
          value={v.rate}
          onChange={onChange}
          options={[
            ["21", "General · 21 %"],
            ["10", "Reducido · 10 %"],
            ["4", "Superreducido · 4 %"],
          ]}
        />
      </>
    );
  if (path === "/calculadora-descuentos")
    return (
      <>
        {field("Precio original (€)", "price")}
        {field("Descuento (%)", "discount")}
      </>
    );
  if (path === "/calculadora-edad")
    return (
      <>
        {field("Fecha de nacimiento", "birth", {
          type: "date",
          min: undefined,
        })}
      </>
    );
  if (path === "/regla-de-tres")
    return (
      <>
        <SelectField
          label="Valor desconocido"
          name="unknown"
          value={v.unknown}
          onChange={onChange}
          options={[
            ["a", "A (primera posición)"],
            ["b", "B (segunda posición)"],
            ["c", "C (tercera posición)"],
            ["d", "D (cuarta posición)"],
          ]}
        />
        <div className="field full">
          <div className="help">
            Completa tres valores de la proporción A / B = C / D; deja vacío el
            que quieras hallar.
          </div>
          <div className="fields" style={{ marginTop: 12 }}>
            {(["a", "b", "c", "d"] as const).map((k) =>
              field(
                `${k.toUpperCase()}${v.unknown === k ? " · desconocido" : ""}`,
                k,
              ),
            )}
          </div>
        </div>
      </>
    );
  if (path === "/dias-entre-fechas")
    return (
      <>
        {field("Fecha inicial", "start", { type: "date", min: undefined })}
        {field("Fecha final", "end", { type: "date", min: undefined })}
        <div className="field full">
          <label
            style={{
              display: "flex",
              alignItems: "center",
              gap: 9,
              fontWeight: 500,
            }}
          >
            <input
              type="checkbox"
              checked={v.inclusive === "true"}
              onChange={(e) => onChange("inclusive", String(e.target.checked))}
              data-testid="input-inclusive"
            />{" "}
            Contar los dos días del intervalo
          </label>
          <span className="help">
            Desactivado: cuenta los días transcurridos, sin contar el día
            inicial.
          </span>
        </div>
      </>
    );
  if (path === "/convertir-kilometros-a-millas")
    return (
      <>
        <SelectField
          label="Conversión"
          name="mode"
          value={v.mode}
          onChange={onChange}
          options={[
            ["km-mi", "Kilómetros → millas"],
            ["mi-km", "Millas → kilómetros"],
          ]}
        />
        {field(v.mode === "km-mi" ? "Kilómetros" : "Millas", "amount")}
      </>
    );
  if (path === "/convertir-kilos-a-libras")
    return (
      <>
        <SelectField
          label="Conversión"
          name="mode"
          value={v.mode}
          onChange={onChange}
          options={[
            ["kg-lb", "Kilogramos → libras"],
            ["lb-kg", "Libras → kilogramos"],
          ]}
        />
        {field(v.mode === "kg-lb" ? "Kilogramos" : "Libras", "amount")}
      </>
    );
  if (path === "/calculadora-propinas")
    return (
      <>
        {field("Importe de la cuenta (€)", "bill")}
        {field("Propina (%)", "tip")}
        {field("Número de personas", "people", { step: "1", min: "1" })}
      </>
    );
  if (path === "/calculadora-ahorro-mensual")
    return (
      <>
        {field("Ahorro inicial (€)", "initial")}
        {field("Aportación mensual (€)", "monthly")}
        {field("Interés anual estimado (%)", "rate")}
        {field("Duración (años)", "years", { min: "0.01", step: "0.1" })}
      </>
    );
  return null;
}
const guideCopy: Record<string, string[]> = {
  "/calculadora-porcentajes": [
    "Para hallar un porcentaje, multiplica la cantidad por el porcentaje y divide entre cien: el 15 % de 80 son 12.",
    "Para comparar dos cantidades, la variación porcentual se calcula respecto al valor inicial. Si ese valor es cero, no existe una base válida para expresar el cambio en porcentaje.",
  ],
  "/calculadora-iva": [
    "Para añadir el impuesto, el cálculo suma al precio neto el porcentaje de IVA correspondiente. Para quitarlo, divide el precio final entre 1 más el tipo en formato decimal.",
    "Los tipos del 21 %, 10 % y 4 % dependen del bien o servicio. Comprueba el tipo aplicable a tu caso antes de utilizar el resultado con fines fiscales.",
  ],
  "/calculadora-descuentos": [
    "Un descuento del 20 % deja el 80 % del precio original. Por ejemplo, en una compra de 120 €, el ahorro sería de 24 € y el precio final, 96 €.",
    "El porcentaje debe estar entre 0 % y 100 %. La herramienta no añade gastos de envío ni otras promociones.",
  ],
  "/calculadora-edad": [
    "La edad se expresa en años, meses y días completos desde la fecha de nacimiento. La fecha se compara usando el calendario local del dispositivo.",
    "La fecha de nacimiento no puede estar en el futuro. El resultado es informativo y no sustituye la comprobación de documentos oficiales.",
  ],
  "/regla-de-tres": [
    "La proporción directa A/B = C/D se resuelve multiplicando en cruz: A × D = B × C. Elige la letra desconocida y completa las otras tres.",
    "Ejemplo: 4/10 = 6/15. Si falta A, el resultado es (10 × 6) ÷ 15 = 4. No se puede dividir entre cero.",
  ],
  "/dias-entre-fechas": [
    "El modo normal devuelve los días naturales transcurridos entre las fechas y funciona aunque las introduzcas en orden inverso.",
    "Activa el recuento inclusivo para sumar también la fecha inicial y la final. Por ejemplo, del 1 al 3 de mayo hay 2 días transcurridos o 3 días inclusivos.",
  ],
  "/convertir-kilometros-a-millas": [
    "Una milla internacional equivale a 1,609344 kilómetros. Para convertir kilómetros a millas, divide los kilómetros entre 1,609344; para volver a kilómetros, multiplica.",
    "El resultado se redondea a dos decimales para facilitar la lectura. La conversión matemática conserva más precisión internamente.",
  ],
  "/convertir-kilos-a-libras": [
    "Un kilogramo equivale aproximadamente a 2,20462262 libras. Multiplica los kilogramos por ese factor para obtener libras y divide para convertir al sistema métrico.",
    "El conversor utiliza la libra avoirdupois internacional y presenta dos decimales.",
  ],
  "/calculadora-propinas": [
    "La propina se calcula sobre el importe de la cuenta, se suma al total y se reparte entre las personas. En una cuenta de 60 € con un 10 % de propina para dos personas, cada una paga 33 €.",
    "Indica un número entero de personas igual o mayor que uno. La herramienta no decide qué porcentaje de propina es adecuado.",
  ],
  "/calculadora-ahorro-mensual": [
    "La estimación convierte el tipo anual indicado en un tipo mensual dividiéndolo entre doce y añade cada aportación al final del mes. Así puedes distinguir el dinero aportado de los intereses estimados.",
    "Es una proyección matemática, no una garantía de rentabilidad. No incluye impuestos, comisiones, inflación ni cambios del tipo de interés.",
  ],
};

function Calculator({ tool }: { tool: Tool }) {
  const [v, setV] = useState<Values>(() => ({ ...baseValues[tool.path] }));
  const result = useMemo(() => {
    const value = calculate(tool.path, v);
    if (/(?:NaN|Infinity|∞)/i.test(`${value.main} ${value.detail}`))
      return {
        main: "—",
        detail:
          "Reduce las cantidades para obtener un resultado que se pueda mostrar.",
        error: "El resultado supera el rango numérico disponible.",
      };
    return value;
  }, [tool.path, v]);
  const update = (key: string, value: string) =>
    setV((old) => {
      const next = { ...old, [key]: value };
      if (tool.path === "/regla-de-tres" && key === "unknown") {
        next[value] = "";
      }
      return next;
    });
  const faq = pageFaqs[tool.path] ?? [];
  const related = tools
    .filter((t) => t.path !== tool.path && t.category === tool.category)
    .slice(0, 4);
  return (
    <Shell path={tool.path}>
      <main>
        <div className="container page-top">
          <Link href="/" data-testid="link-breadcrumb-home">
            Inicio
          </Link>
          <span aria-hidden="true"> / </span>
          <span>{tool.title}</span>
        </div>
        <section className="container">
          <div className="calculator-layout">
            <div>
              <span className="eyebrow">{tool.category}</span>
              <h1 className="page-title">{tool.title}</h1>
              <p className="lead">
                {tool.description} Introduce tus datos y consulta el resultado
                al instante, sin registro.
              </p>
              <div className="calc-box">
                <div className="fields">
                  <CalculatorFields path={tool.path} v={v} onChange={update} />
                </div>
                <div
                  className="result-box"
                  role="status"
                  aria-live="polite"
                  data-testid="result-calculadora"
                >
                  <div className="result-label">Resultado</div>
                  <div className="result-main">{result.main}</div>
                  <div className="result-detail">{result.detail}</div>
                </div>
                {result.error && (
                  <div
                    className="error-message"
                    role="alert"
                    data-testid="error-calculadora"
                  >
                    {result.error}
                  </div>
                )}
              </div>
              <AdSlot compact />
              <article className="article-copy">
                <h2>Cómo usar {tool.title.toLowerCase()}</h2>
                <p>
                  {tool.description} Rellena los campos con valores válidos y el
                  cálculo se actualizará automáticamente. Los resultados son
                  orientativos y se muestran con formato español.
                </p>
                {guideCopy[tool.path]?.map((paragraph) => (
                  <p key={paragraph}>{paragraph}</p>
                ))}
              </article>
            </div>
            <aside>
              <AdSlot compact />
              <div className="aside-box">
                <h2>También puede interesarte</h2>
                <div className="related-list">
                  {(related.length
                    ? related
                    : tools.filter((t) => t.path !== tool.path).slice(0, 4)
                  ).map((t) => (
                    <Link
                      href={t.path}
                      key={t.path}
                      data-testid={`link-related-${t.path.slice(1)}`}
                    >
                      {t.title} <span aria-hidden="true">→</span>
                    </Link>
                  ))}
                </div>
              </div>
              <div className="aside-box">
                <h2>Una herramienta sencilla</h2>
                <p
                  style={{
                    fontSize: 13,
                    color: "#6b7c8b",
                    lineHeight: 1.65,
                    margin: 0,
                  }}
                >
                  CalculaFácil no solicita una cuenta y procesa tus datos
                  directamente en tu navegador.
                </p>
              </div>
            </aside>
          </div>
        </section>
        {faq.length > 0 && <Faq items={faq} />}
      </main>
    </Shell>
  );
}

function LegalContent({ path }: { path: string }) {
  const title = legalPages.find((p) => p.path === path)?.title ?? "Información";
  if (path === "/contacto") return <ContactPage />;
  if (path === "/sobre-nosotros")
    return (
      <>
        <h1 className="page-title">Sobre CalculaFácil</h1>
        <div className="article-copy">
          <p>
            CalculaFácil nace para resolver preguntas cotidianas sin
            convertirlas en un proceso complicado. Reunimos calculadoras y
            conversores que se entienden de un vistazo y entregan el resultado
            mientras escribes.
          </p>
          <h2>Claro y accesible</h2>
          <p>
            Las herramientas son gratuitas, no requieren registro y están
            pensadas para funcionar tanto en el ordenador como en el móvil. No
            se envían a un servidor las cantidades que introduces en una
            calculadora.
          </p>
          <h2>Una ayuda, no un sustituto profesional</h2>
          <p>
            Los resultados son informativos. En materias fiscales, financieras o
            legales, consulta fuentes oficiales o a un profesional para tomar
            decisiones que dependan de tu situación concreta.
          </p>
        </div>
      </>
    );
  const body =
    path === "/politica-de-privacidad" ? (
      <>
        <p>
          Este texto es una plantilla de trabajo. Antes de publicarlo, el
          titular debe revisarlo, completarlo y adaptarlo al tratamiento real de
          datos personales del sitio.
        </p>
        <h2>Responsable del tratamiento</h2>
        <p>
          Responsable: [NOMBRE O RAZÓN SOCIAL DEL TITULAR]. NIF: [NIF].
          Dirección: [DIRECCIÓN POSTAL COMPLETA]. Contacto de privacidad:
          [CORREO ELECTRÓNICO]. Dominio: [DOMINIO DEL SITIO].
        </p>
        <h2>Datos y finalidades</h2>
        <p>
          Las operaciones de las calculadoras se realizan en el navegador y no
          requieren introducir datos identificativos. Si escribes al contacto
          indicado, el mensaje se gestionará para responder a tu consulta. El
          titular debe detallar aquí cualquier tratamiento adicional que
          realmente realice.
        </p>
        <h2>Derechos y conservación</h2>
        <p>
          Completar con los plazos aplicables, la base jurídica, los
          destinatarios, los derechos de las personas interesadas y el modo de
          ejercerlos, además de la autoridad de control competente.
        </p>
      </>
    ) : path === "/politica-de-cookies" ? (
      <>
        <p>
          Esta página es una plantilla editable. Debe revisarse para reflejar
          las tecnologías realmente instaladas en el dominio y la normativa
          aplicable.
        </p>
        <h2>Preferencias en este sitio</h2>
        <p>
          La preferencia elegida para este aviso se guarda en el almacenamiento
          local del navegador. No se carga analítica ni publicidad de terceros
          desde esta aplicación.
        </p>
        <h2>Cómo cambiar la elección</h2>
        <p>
          Usa “Preferencias de cookies” en el pie de página para volver a abrir
          el panel. Las cookies o tecnologías que el titular incorpore en el
          futuro deben describirse aquí con su finalidad, duración y proveedor.
        </p>
      </>
    ) : (
      <>
        <p>
          Este aviso legal es una plantilla de trabajo para España. No
          constituye asesoramiento jurídico ni acredita por sí solo el
          cumplimiento normativo.
        </p>
        <h2>Titularidad</h2>
        <p>
          Titular: [NOMBRE O RAZÓN SOCIAL]. NIF: [NIF]. Domicilio: [DIRECCIÓN
          COMPLETA]. Correo electrónico: [CONTACTO]. Dominio: [DOMINIO].
        </p>
        <h2>Condiciones de uso</h2>
        <p>
          Completar con las condiciones de acceso, responsabilidades, propiedad
          intelectual, enlaces y cualquier otra información que resulte
          aplicable al servicio antes de publicar.
        </p>
        <h2>Fechas</h2>
        <p>
          Fecha de entrada en vigor: [DD/MM/AAAA]. Última actualización:
          [DD/MM/AAAA].
        </p>
      </>
    );
  return (
    <>
      <h1 className="page-title">{title}</h1>
      <div className="legal-placeholder">
        <strong>Plantilla editable para España:</strong> antes de publicar,
        incorpora y verifica los datos reales: titular [NOMBRE O RAZÓN SOCIAL],
        NIF [NIF], domicilio [DIRECCIÓN POSTAL], contacto [CORREO O MEDIO DE
        CONTACTO], dominio [DOMINIO], fecha de entrada en vigor [DD/MM/AAAA] y
        última actualización [DD/MM/AAAA]. No es asesoramiento jurídico ni
        acredita por sí sola el cumplimiento completo.
      </div>
      <div className="article-copy">{body}</div>
    </>
  );
}
function ContactPage() {
  const [name, setName] = useState(""),
    [email, setEmail] = useState(""),
    [message, setMessage] = useState(""),
    [error, setError] = useState("");
  const submit = (e: React.FormEvent) => {
    e.preventDefault();
    if (name.trim().length < 2) {
      setError("Escribe tu nombre (al menos dos caracteres).");
      return;
    }
    if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) {
      setError("Introduce una dirección de correo válida.");
      return;
    }
    if (message.trim().length < 10) {
      setError("El mensaje debe tener al menos 10 caracteres.");
      return;
    }
    setError("");
    const subject = encodeURIComponent(`Consulta de ${name.trim()}`);
    const body = encodeURIComponent(
      `Nombre: ${name.trim()}\nCorreo: ${email.trim()}\n\n${message.trim()}`,
    );
    window.location.href = `mailto:contacto@example.com?subject=${subject}&body=${body}`;
  };
  return (
    <>
      <h1 className="page-title">Contacto</h1>
      <p className="lead">
        ¿Tienes una duda o una sugerencia? Prepara tu mensaje y se abrirá tu
        aplicación de correo.
      </p>
      <div className="legal-placeholder">
        <strong>Destino de ejemplo:</strong> contacto@example.com. El titular
        debe sustituir esta dirección real antes de publicar.
      </div>
      <form onSubmit={submit} className="calc-box" noValidate>
        <div className="fields">
          <InputField
            label="Nombre"
            name="contact-name"
            type="text"
            value={name}
            onChange={(_, v) => setName(v)}
          />
          <InputField
            label="Correo electrónico"
            name="contact-email"
            type="email"
            value={email}
            onChange={(_, v) => setEmail(v)}
          />
          <InputField
            label="Mensaje"
            name="contact-message"
            type="text"
            value={message}
            onChange={(_, v) => setMessage(v)}
          >
            <textarea
              id="field-contact-message"
              value={message}
              onChange={(e) => setMessage(e.target.value)}
              data-testid="input-contact-message"
              aria-label="Mensaje"
              placeholder="Cuéntanos en qué podemos ayudarte"
            />
          </InputField>
        </div>
        {error && (
          <div
            className="error-message"
            role="alert"
            data-testid="error-contacto"
          >
            {error}
          </div>
        )}
        <button
          className="button"
          style={{ marginTop: 18 }}
          type="submit"
          data-testid="button-contacto-enviar"
        >
          Preparar correo
        </button>
        <p className="help" style={{ marginTop: 12 }}>
          No se envía ningún dato desde este sitio: el mensaje se abre en tu
          cliente de correo.
        </p>
      </form>
    </>
  );
}
function InfoPage({ path }: { path: string }) {
  return (
    <Shell path={path}>
      <main>
        <div className="container page-top">
          <Link href="/" data-testid="link-breadcrumb-home">
            Inicio
          </Link>
          <span aria-hidden="true"> / </span>
          <span>{legalPages.find((p) => p.path === path)?.title}</span>
        </div>
        <section
          className="container"
          style={{ maxWidth: 840, paddingBottom: 55 }}
        >
          <LegalContent path={path} />
        </section>
      </main>
    </Shell>
  );
}
function NotFound() {
  return (
    <Shell path="/">
      <main className="container" style={{ padding: "90px 0", minHeight: 380 }}>
        <span className="eyebrow">Página no encontrada</span>
        <h1 className="page-title">No encontramos esa página</h1>
        <p className="lead">
          Puede que el enlace haya cambiado. Vuelve a las calculadoras y
          encuentra la herramienta que necesitas.
        </p>
        <Link
          className="button"
          href="/"
          style={{
            display: "inline-block",
            textDecoration: "none",
            marginTop: 14,
          }}
          data-testid="link-volver-inicio"
        >
          Ir al inicio
        </Link>
      </main>
    </Shell>
  );
}
function RoutedErrorBoundary({ children }: { children: React.ReactNode }) {
  const [location] = useLocation();
  return <ErrorBoundary resetKey={location}>{children}</ErrorBoundary>;
}
function Router() {
  return (
    <RoutedErrorBoundary>
      <Switch>
        <Route path="/" component={Home} />
        {tools.map((t) => (
          <Route
            key={t.path}
            path={t.path}
            component={() => <Calculator tool={t} />}
          />
        ))}
        {legalPages.map((p) => (
          <Route
            key={p.path}
            path={p.path}
            component={() => <InfoPage path={p.path} />}
          />
        ))}
        <Route component={NotFound} />
      </Switch>
    </RoutedErrorBoundary>
  );
}
function App() {
  return (
    <WouterRouter base={import.meta.env.BASE_URL.replace(/\/$/, "")}>
      <Router />
    </WouterRouter>
  );
}
export default App;
