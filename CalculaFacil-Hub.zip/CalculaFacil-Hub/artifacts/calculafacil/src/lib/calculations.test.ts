import assert from "node:assert/strict";
import test from "node:test";
import { calculate } from "./calculations.ts";

test("calcula un porcentaje y su variación", () => {
  assert.equal(
    calculate("/calculadora-porcentajes", {
      mode: "amount",
      amount: "250",
      percent: "15",
    }).main,
    "37,5",
  );
  assert.equal(
    calculate("/calculadora-porcentajes", {
      mode: "difference",
      from: "80",
      to: "100",
    }).main,
    "25 %",
  );
  assert.ok(
    calculate("/calculadora-porcentajes", {
      mode: "difference",
      from: "0",
      to: "100",
    }).error,
  );
});

test("añade y quita el IVA correctamente", () => {
  assert.match(
    calculate("/calculadora-iva", {
      mode: "add",
      amount: "100",
      rate: "21",
    }).main,
    /121/,
  );
  assert.match(
    calculate("/calculadora-iva", {
      mode: "remove",
      amount: "121",
      rate: "21",
    }).main,
    /100/,
  );
});

test("calcula precio final y ahorro de un descuento", () => {
  const result = calculate("/calculadora-descuentos", {
    price: "120",
    discount: "20",
  });
  assert.match(result.main, /96/);
  assert.match(result.detail, /24/);
  assert.ok(
    calculate("/calculadora-descuentos", {
      price: "120",
      discount: "101",
    }).error,
  );
});

test("calcula la edad en la fecha local y rechaza fechas futuras", () => {
  const today = new Date();
  const birth = `${today.getFullYear()}-${String(today.getMonth() + 1).padStart(2, "0")}-${String(today.getDate()).padStart(2, "0")}`;
  const result = calculate("/calculadora-edad", { birth });
  assert.match(result.detail, /^0 años, 0 meses y 0 días/);
  assert.ok(calculate("/calculadora-edad", { birth: "2999-01-01" }).error);
});

test("resuelve cualquiera de los cuatro términos de una regla de tres", () => {
  const cases = [
    ["a", "", "2", "6", "3", "4"],
    ["b", "4", "", "6", "3", "2"],
    ["c", "4", "2", "", "3", "6"],
    ["d", "4", "2", "6", "", "3"],
  ];
  for (const [unknown, a, b, c, d, expected] of cases) {
    assert.equal(
      calculate("/regla-de-tres", { unknown, a, b, c, d }).main,
      expected,
    );
  }
  assert.ok(
    calculate("/regla-de-tres", {
      unknown: "a",
      a: "",
      b: "2",
      c: "6",
      d: "0",
    }).error,
  );
});

test("cuenta días naturales entre fechas y valida el calendario", () => {
  assert.equal(
    calculate("/dias-entre-fechas", {
      start: "2024-02-28",
      end: "2024-03-01",
      inclusive: "false",
    }).main,
    "2 días",
  );
  assert.equal(
    calculate("/dias-entre-fechas", {
      start: "2024-02-28",
      end: "2024-03-01",
      inclusive: "true",
    }).main,
    "3 días",
  );
  assert.ok(
    calculate("/dias-entre-fechas", {
      start: "2025-02-30",
      end: "2025-03-01",
      inclusive: "false",
    }).error,
  );
});

test("convierte kilómetros, millas, kilogramos y libras", () => {
  assert.match(
    calculate("/convertir-kilometros-a-millas", {
      mode: "km-mi",
      amount: "10",
    }).main,
    /6,21 mi/,
  );
  assert.match(
    calculate("/convertir-kilometros-a-millas", {
      mode: "mi-km",
      amount: "6.21371",
    }).main,
    /10 km/,
  );
  assert.match(
    calculate("/convertir-kilos-a-libras", {
      mode: "kg-lb",
      amount: "1",
    }).main,
    /2,2 lb/,
  );
  assert.match(
    calculate("/convertir-kilos-a-libras", {
      mode: "lb-kg",
      amount: "2.2046226218",
    }).main,
    /1 kg/,
  );
});

test("calcula la propina total y la parte por persona", () => {
  const result = calculate("/calculadora-propinas", {
    bill: "60",
    tip: "10",
    people: "2",
  });
  assert.match(result.main, /33/);
  assert.match(result.detail, /6/);
  assert.ok(
    calculate("/calculadora-propinas", {
      bill: "60",
      tip: "10",
      people: "0",
    }).error,
  );
});

test("proyecta ahorro mensual con aportaciones al final del mes", () => {
  const result = calculate("/calculadora-ahorro-mensual", {
    initial: "100",
    monthly: "100",
    rate: "0",
    years: "1",
  });
  assert.match(result.main, /1300/);
  assert.match(result.detail, /Aportado:.*1300/);
  assert.ok(
    calculate("/calculadora-ahorro-mensual", {
      initial: "100",
      monthly: "100",
      rate: "-1",
      years: "1",
    }).error,
  );
});
