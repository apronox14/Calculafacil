export type Values = Record<string, string>;

const euro = (value: number) =>
  new Intl.NumberFormat("es-ES", {
    style: "currency",
    currency: "EUR",
    maximumFractionDigits: 2,
  }).format(value);

const number = (value: number, digits = 2) =>
  new Intl.NumberFormat("es-ES", { maximumFractionDigits: digits }).format(
    value,
  );

const todayISO = () => {
  const date = new Date();
  return `${date.getFullYear()}-${String(date.getMonth() + 1).padStart(2, "0")}-${String(date.getDate()).padStart(2, "0")}`;
};

export const baseValues: Record<string, Values> = {
  "/calculadora-porcentajes": {
    mode: "amount",
    amount: "250",
    percent: "15",
    from: "80",
    to: "100",
  },
  "/calculadora-iva": { mode: "add", amount: "100", rate: "21" },
  "/calculadora-descuentos": { price: "120", discount: "20" },
  "/calculadora-edad": { birth: "1990-06-15" },
  "/regla-de-tres": { unknown: "a", a: "", b: "10", c: "6", d: "15" },
  "/dias-entre-fechas": {
    start: "2025-01-01",
    end: todayISO(),
    inclusive: "false",
  },
  "/convertir-kilometros-a-millas": { mode: "km-mi", amount: "10" },
  "/convertir-kilos-a-libras": { mode: "kg-lb", amount: "10" },
  "/calculadora-propinas": { bill: "60", tip: "10", people: "2" },
  "/calculadora-ahorro-mensual": {
    initial: "1000",
    monthly: "200",
    rate: "3",
    years: "5",
  },
};

function isValidDate(value: string) {
  if (!/^\d{4}-\d{2}-\d{2}$/.test(value)) return false;
  const [year, month, day] = value.split("-").map(Number);
  const date = new Date(Date.UTC(year, month - 1, day));
  return (
    date.getUTCFullYear() === year &&
    date.getUTCMonth() === month - 1 &&
    date.getUTCDate() === day
  );
}

function dateKey(date: Date) {
  return Date.UTC(date.getFullYear(), date.getMonth(), date.getDate());
}

function addMonthsClamped(date: Date, months: number) {
  const target = new Date(date.getFullYear(), date.getMonth() + months, 1);
  const lastDay = new Date(
    target.getFullYear(),
    target.getMonth() + 1,
    0,
  ).getDate();
  return new Date(
    target.getFullYear(),
    target.getMonth(),
    Math.min(date.getDate(), lastDay),
  );
}

function exactAge(birthDate: Date, today: Date) {
  let years = today.getFullYear() - birthDate.getFullYear();
  if (dateKey(addMonthsClamped(birthDate, years * 12)) > dateKey(today)) {
    years -= 1;
  }

  const afterYears = addMonthsClamped(birthDate, years * 12);
  let months = 0;
  while (
    months < 11 &&
    dateKey(addMonthsClamped(afterYears, months + 1)) <= dateKey(today)
  ) {
    months += 1;
  }

  const afterMonths = addMonthsClamped(afterYears, months);
  const days = (dateKey(today) - dateKey(afterMonths)) / 86_400_000;
  const nextBirthday = addMonthsClamped(birthDate, (years + 1) * 12);
  const daysToBirthday = (dateKey(nextBirthday) - dateKey(today)) / 86_400_000;

  return { years, months, days, daysToBirthday };
}

function safeNum(value: string) {
  if (value.trim() === "") return null;
  const parsed = Number(value);
  return Number.isFinite(parsed) ? parsed : null;
}

export function calculate(
  path: string,
  values: Values,
): { main: string; detail: string; error: string } {
  const invalid = {
    main: "—",
    detail: "Completa los datos para ver el resultado.",
    error: "",
  };
  const n = (key: string) => safeNum(values[key] ?? "");
  const date = (key: string) => values[key] ?? "";

  if (path === "/calculadora-porcentajes") {
    if (values.mode === "difference") {
      const start = n("from");
      const end = n("to");
      if (start === null || end === null) return invalid;
      if (start <= 0 || end < 0) {
        return {
          ...invalid,
          error:
            "El valor inicial debe ser mayor que cero y el valor final no puede ser negativo.",
        };
      }
      const delta = ((end - start) / start) * 100;
      return {
        main: `${number(delta)} %`,
        detail: `${delta >= 0 ? "Aumento" : "Disminución"} de ${number(Math.abs(end - start))} respecto al valor inicial.`,
        error: "",
      };
    }

    const amount = n("amount");
    const percent = n("percent");
    if (amount === null || percent === null) return invalid;
    if (amount < 0 || percent < 0) {
      return {
        ...invalid,
        error: "Introduce valores iguales o mayores que cero.",
      };
    }
    const result = (amount * percent) / 100;
    return {
      main: number(result),
      detail: `El ${number(percent)} % de ${number(amount)} es ${number(result)}.`,
      error: "",
    };
  }

  if (path === "/calculadora-iva") {
    const amount = n("amount");
    const rate = n("rate");
    if (amount === null || rate === null) return invalid;
    if (amount < 0) {
      return { ...invalid, error: "El importe no puede ser negativo." };
    }
    if (values.mode === "add") {
      const tax = (amount * rate) / 100;
      return {
        main: euro(amount + tax),
        detail: `Base imponible ${euro(amount)} · IVA ${euro(tax)} (${number(rate)} %).`,
        error: "",
      };
    }
    const base = amount / (1 + rate / 100);
    return {
      main: euro(base),
      detail: `Precio con IVA ${euro(amount)} · IVA incluido ${euro(amount - base)} (${number(rate)} %).`,
      error: "",
    };
  }

  if (path === "/calculadora-descuentos") {
    const price = n("price");
    const discount = n("discount");
    if (price === null || discount === null) return invalid;
    if (price < 0 || discount < 0 || discount > 100) {
      return {
        ...invalid,
        error:
          "El precio no puede ser negativo y el descuento debe estar entre 0 % y 100 %.",
      };
    }
    return {
      main: euro(price * (1 - discount / 100)),
      detail: `Ahorras ${euro((price * discount) / 100)} sobre el precio original de ${euro(price)}.`,
      error: "",
    };
  }

  if (path === "/calculadora-edad") {
    const raw = date("birth");
    if (!raw) return invalid;
    if (!isValidDate(raw)) {
      return { ...invalid, error: "Introduce una fecha de nacimiento válida." };
    }
    const [year, month, day] = raw.split("-").map(Number);
    const birth = new Date(year, month - 1, day);
    const today = new Date();
    today.setHours(0, 0, 0, 0);
    if (dateKey(birth) > dateKey(today)) {
      return {
        ...invalid,
        error: "La fecha de nacimiento no puede estar en el futuro.",
      };
    }
    const age = exactAge(birth, today);
    return {
      main: `${age.years} años`,
      detail: `${age.years} años, ${age.months} meses y ${age.days} días · Próximo cumpleaños en ${age.daysToBirthday} ${age.daysToBirthday === 1 ? "día" : "días"}.`,
      error: "",
    };
  }

  if (path === "/regla-de-tres") {
    const keys = ["a", "b", "c", "d"] as const;
    const unknown = values.unknown;
    if (!keys.includes(unknown as (typeof keys)[number])) {
      return { ...invalid, error: "Selecciona qué valor quieres calcular." };
    }
    const nums = keys.map((key) => n(key));
    if (
      nums.some((value, index) => keys[index] !== unknown && value === null)
    ) {
      return invalid;
    }
    if (
      nums.some(
        (value, index) =>
          keys[index] !== unknown && value !== null && value < 0,
      )
    ) {
      return {
        ...invalid,
        error: "Los valores conocidos no pueden ser negativos.",
      };
    }

    const [a, b, c, d] = nums;
    let result: number;
    let denominator: number;
    if (unknown === "a") {
      denominator = d as number;
      result = ((b as number) * (c as number)) / denominator;
    } else if (unknown === "b") {
      denominator = c as number;
      result = ((a as number) * (d as number)) / denominator;
    } else if (unknown === "c") {
      denominator = b as number;
      result = ((a as number) * (d as number)) / denominator;
    } else {
      denominator = a as number;
      result = ((b as number) * (c as number)) / denominator;
    }
    if (denominator === 0) {
      return {
        ...invalid,
        error: "El divisor de la proporción no puede ser cero.",
      };
    }
    if (!Number.isFinite(result)) {
      return {
        ...invalid,
        error: "No se puede obtener un resultado válido con esos valores.",
      };
    }
    return {
      main: number(result),
      detail: `Proporción directa: ${unknown.toUpperCase()} es el valor que faltaba.`,
      error: "",
    };
  }

  if (path === "/dias-entre-fechas") {
    const start = date("start");
    const end = date("end");
    if (!start || !end) return invalid;
    if (!isValidDate(start) || !isValidDate(end)) {
      return { ...invalid, error: "Selecciona dos fechas válidas." };
    }
    const difference =
      Math.abs(
        Date.parse(`${end}T00:00:00Z`) - Date.parse(`${start}T00:00:00Z`),
      ) / 86_400_000;
    const count = difference + (values.inclusive === "true" ? 1 : 0);
    return {
      main: `${number(count, 0)} días`,
      detail: `Diferencia entre fechas: ${number(difference, 0)} días. ${values.inclusive === "true" ? "Incluye ambos días." : "No incluye el día inicial."}`,
      error: "",
    };
  }

  if (
    path === "/convertir-kilometros-a-millas" ||
    path === "/convertir-kilos-a-libras"
  ) {
    const amount = n("amount");
    if (amount === null) return invalid;
    if (amount < 0) {
      return { ...invalid, error: "La cantidad no puede ser negativa." };
    }
    const isKilometres = path.includes("kilometros");
    const forward = values.mode === (isKilometres ? "km-mi" : "kg-lb");
    const result = isKilometres
      ? forward
        ? amount / 1.609344
        : amount * 1.609344
      : forward
        ? amount * 2.2046226218
        : amount / 2.2046226218;
    const fromUnit = isKilometres
      ? forward
        ? "km"
        : "mi"
      : forward
        ? "kg"
        : "lb";
    const toUnit = isKilometres
      ? forward
        ? "mi"
        : "km"
      : forward
        ? "lb"
        : "kg";
    return {
      main: `${number(result)} ${toUnit}`,
      detail: `${number(amount)} ${fromUnit} = ${number(result)} ${toUnit}.`,
      error: "",
    };
  }

  if (path === "/calculadora-propinas") {
    const bill = n("bill");
    const tip = n("tip");
    const people = n("people");
    if (bill === null || tip === null || people === null) return invalid;
    if (bill < 0 || tip < 0 || people < 1 || !Number.isInteger(people)) {
      return {
        ...invalid,
        error:
          "La cuenta y la propina no pueden ser negativas; indica al menos una persona.",
      };
    }
    const gratuity = (bill * tip) / 100;
    const total = bill + gratuity;
    return {
      main: `${euro(total / people)} por persona`,
      detail: `Propina total ${euro(gratuity)} (${euro(gratuity / people)} por persona) · Cuenta total ${euro(total)}.`,
      error: "",
    };
  }

  if (path === "/calculadora-ahorro-mensual") {
    const initial = n("initial");
    const monthly = n("monthly");
    const rate = n("rate");
    const years = n("years");
    if (
      initial === null ||
      monthly === null ||
      rate === null ||
      years === null
    ) {
      return invalid;
    }
    if (initial < 0 || monthly < 0 || rate < 0 || years <= 0 || years > 100) {
      return {
        ...invalid,
        error:
          "Usa cantidades y tipo no negativos, y una duración mayor que 0 y no superior a 100 años.",
      };
    }
    const months = Math.round(years * 12);
    const monthlyRate = rate / 100 / 12;
    let balance = initial;
    for (let month = 0; month < months; month += 1) {
      balance = balance * (1 + monthlyRate) + monthly;
    }
    const contributions = initial + monthly * months;
    const interest = balance - contributions;
    return {
      main: euro(balance),
      detail: `Aportado: ${euro(contributions)} · Intereses estimados: ${euro(interest)} · Plazo: ${months} meses. Interés compuesto mensual estimado; aportación al final de cada mes.`,
      error: "",
    };
  }

  return invalid;
}
