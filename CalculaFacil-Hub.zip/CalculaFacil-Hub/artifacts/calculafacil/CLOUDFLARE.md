# Publicar CalculaFácil en Cloudflare Pages

La web es estática y no necesita base de datos, servidor ni servicios de pago.

## Configuración de Pages

- **Comando de compilación:** `pnpm --filter @workspace/calculafacil run build`
- **Directorio de salida:** `artifacts/calculafacil/dist/public`
- **Versión de Node:** 22.12 o superior
- **Dominio:** configura el dominio que vayas a utilizar en Cloudflare Pages.
- **Variable de compilación `VITE_SITE_URL`:** la URL pública completa, por ejemplo `https://www.tu-dominio.es`.

El archivo `public/_redirects` conserva las rutas limpias de las calculadoras al abrirlas directamente. La carpeta `public` también incluye `robots.txt` y `sitemap.xml`.

## Antes de publicar

1. Configura `VITE_SITE_URL` con el dominio definitivo. La compilación genera una página HTML y metadatos propios para cada ruta, además del sitemap y `robots.txt`.
2. Completa los datos marcados como pendientes en las páginas legales y actualiza el email de contacto.
3. Cuando tengas tu identificador real de AdSense, intégralo solo después de configurar y probar el consentimiento para cookies. No hay anuncios ni rastreadores activos por defecto.
4. Revisa la versión publicada en móvil y vuelve a enviar el sitemap a Google Search Console.

## Actualizar la web

Edita las páginas y calculadoras dentro de `src/`. Para ver los cambios, ejecuta `pnpm --filter @workspace/calculafacil run dev`. Para generar la versión estática que se publica, usa el comando de compilación indicado arriba.
