import { mkdir, readFile, writeFile } from "node:fs/promises";
import path from "node:path";
import { fileURLToPath } from "node:url";

const root = path.resolve(path.dirname(fileURLToPath(import.meta.url)), "..");
const publicDir = path.join(root, "dist", "public");
const siteUrl = (
  process.env.VITE_SITE_URL || "https://calculafacil.es"
).replace(/\/$/, "");

const pages = [
  {
    path: "/",
    title: "Calculadoras gratuitas online | CalculaFácil",
    description:
      "Calcula, convierte y descubre resultados fácilmente con herramientas gratuitas, claras y rápidas. Sin registros y sin pagar.",
    intro:
      "Todas tus calculadoras gratuitas en un solo lugar. Calcula, convierte y descubre resultados fácilmente, sin registros y sin pagar.",
    faq: [
      {
        q: "¿Las calculadoras de CalculaFácil son gratuitas?",
        a: "Sí. Puedes usar todas las herramientas sin registro y sin pagar. Los cálculos se realizan directamente en tu navegador.",
      },
      {
        q: "¿Se guardan los números que introduzco?",
        a: "Los valores de las calculadoras no se envían a un servidor. La preferencia de cookies se guarda localmente en este dispositivo.",
      },
      {
        q: "¿Puedo usar las herramientas desde el móvil?",
        a: "Sí. La página se adapta a pantallas pequeñas y los campos se pueden manejar con teclado o pantalla táctil.",
      },
    ],
  },
  {
    path: "/calculadora-porcentajes",
    title: "Calculadora de porcentajes online gratis | CalculaFácil",
    description:
      "Calcula qué porcentaje representa una cantidad o la variación entre dos valores. Fórmulas claras y resultado al instante, gratis.",
    intro:
      "Calcula un porcentaje de cualquier cantidad o mide el cambio porcentual entre un valor inicial y otro final. Para hallar un porcentaje, multiplica la cantidad por el porcentaje y divide entre cien.",
    faq: [
      {
        q: "¿Cómo se calcula un porcentaje de una cantidad?",
        a: "Multiplica la cantidad por el porcentaje y divide el resultado entre 100. Por ejemplo, el 15 % de 80 es 12.",
      },
      {
        q: "¿Cómo se calcula la diferencia porcentual?",
        a: "Compara el cambio con el valor inicial: (valor final − valor inicial) ÷ valor inicial × 100.",
      },
    ],
  },
  {
    path: "/calculadora-iva",
    title: "Calculadora de IVA 21 %, 10 % y 4 % | CalculaFácil",
    description:
      "Añade el IVA al precio o calcula la base imponible a partir del precio final. Incluye los tipos del 21 %, 10 % y 4 %.",
    intro:
      "Añade el IVA a un precio neto o calcula la base imponible desde un precio con IVA incluido. Puedes elegir los tipos del 21 %, 10 % y 4 %; confirma siempre qué tipo corresponde a cada bien o servicio.",
    faq: [
      {
        q: "¿Qué tipos de IVA puedo calcular?",
        a: "La herramienta incluye los tipos general del 21 %, reducido del 10 % y superreducido del 4 %. Comprueba cuál corresponde a cada producto o servicio.",
      },
      {
        q: "¿Cómo se obtiene la base imponible al quitar el IVA?",
        a: "Divide el precio con IVA entre 1 más el tipo expresado en decimal. No se debe restar simplemente el porcentaje del precio final.",
      },
    ],
  },
  {
    path: "/calculadora-descuentos",
    title: "Calculadora de descuentos y precio final | CalculaFácil",
    description:
      "Calcula el precio final tras una rebaja y descubre cuánto ahorras. Introduce el precio original y el porcentaje de descuento.",
    intro:
      "Introduce el precio original y el porcentaje de descuento para conocer el importe que pagarás y el ahorro. El precio final es el precio inicial multiplicado por uno menos el descuento expresado como fracción.",
    faq: [
      {
        q: "¿Cómo se calcula el precio tras un descuento?",
        a: "Multiplica el precio original por (1 − descuento/100). La diferencia con el precio inicial es el ahorro.",
      },
    ],
  },
  {
    path: "/calculadora-edad",
    title: "Calculadora de edad exacta y cumpleaños | CalculaFácil",
    description:
      "Calcula tu edad en años, meses y días y consulta cuánto falta para tu próximo cumpleaños con esta herramienta gratuita.",
    intro:
      "Introduce tu fecha de nacimiento para conocer los años, meses y días transcurridos y los días que faltan para tu próximo cumpleaños.",
    faq: [
      {
        q: "¿Cómo se calcula la edad exacta?",
        a: "Se comparan el año, el mes y el día de nacimiento con la fecha actual, teniendo en cuenta si el cumpleaños de este año ya ha pasado.",
      },
    ],
  },
  {
    path: "/regla-de-tres",
    title: "Calculadora de regla de tres directa | CalculaFácil",
    description:
      "Resuelve una proporción directa indicando tres valores conocidos. Completa A/B = C/D y calcula el dato que falta.",
    intro:
      "Completa la proporción directa A/B = C/D y elige qué valor quieres averiguar. La igualdad se resuelve multiplicando en cruz, con control de divisiones entre cero.",
    faq: [
      {
        q: "¿Qué es una regla de tres directa?",
        a: "Es una proporción en la que dos magnitudes cambian en la misma relación. El valor desconocido se obtiene multiplicando en cruz y dividiendo.",
      },
    ],
  },
  {
    path: "/dias-entre-fechas",
    title: "Calculadora de días entre dos fechas | CalculaFácil",
    description:
      "Cuenta los días naturales entre dos fechas y elige si quieres incluir ambos extremos del intervalo.",
    intro:
      "Selecciona una fecha inicial y otra final para contar los días naturales que las separan. Activa el modo inclusivo si necesitas contar también el primer y el último día.",
    faq: [
      {
        q: "¿El resultado incluye el día inicial?",
        a: "Por defecto se muestran los días transcurridos. Puedes activar el modo inclusivo para contar tanto la fecha inicial como la final.",
      },
    ],
  },
  {
    path: "/convertir-kilometros-a-millas",
    title: "Conversor de kilómetros a millas y viceversa | CalculaFácil",
    description:
      "Convierte kilómetros a millas o millas a kilómetros al instante usando el factor exacto de la milla internacional.",
    intro:
      "Convierte en ambas direcciones con el factor exacto: una milla internacional equivale a 1,609344 kilómetros. El resultado se presenta con formato numérico español.",
    faq: [
      {
        q: "¿Cuál es el factor de conversión de kilómetros a millas?",
        a: "Una milla internacional equivale exactamente a 1,609344 kilómetros. Para pasar de kilómetros a millas, divide entre ese factor.",
      },
    ],
  },
  {
    path: "/convertir-kilos-a-libras",
    title: "Conversor de kilos a libras y viceversa | CalculaFácil",
    description:
      "Convierte kilogramos a libras y libras a kilogramos. Resultados rápidos con el factor internacional de conversión.",
    intro:
      "Pasa de kilogramos a libras o al revés. Un kilogramo equivale aproximadamente a 2,20462262 libras; el resultado se redondea para facilitar la lectura.",
    faq: [
      {
        q: "¿Cuántas libras tiene un kilogramo?",
        a: "Un kilogramo equivale aproximadamente a 2,20462262 libras. El conversor muestra el resultado con dos decimales.",
      },
    ],
  },
  {
    path: "/calculadora-propinas",
    title: "Calculadora de propinas y cuenta por persona | CalculaFácil",
    description:
      "Calcula la propina de una cuenta, el total con propina y cuánto paga cada persona al dividir la cuenta.",
    intro:
      "Indica el importe de la cuenta, el porcentaje que quieres dejar y el número de personas. Verás la propina total, el total de la cuenta y el importe por persona.",
    faq: [
      {
        q: "¿Cómo se reparte la propina?",
        a: "La propina se calcula sobre el importe de la cuenta y se suma al total. Después, el total y la propina se dividen entre el número de personas.",
      },
    ],
  },
  {
    path: "/calculadora-ahorro-mensual",
    title: "Calculadora de ahorro mensual e interés compuesto | CalculaFácil",
    description:
      "Proyecta tu ahorro con saldo inicial, aportaciones mensuales e interés estimado. Consulta aportaciones e intereses por separado.",
    intro:
      "Estima el saldo futuro a partir de un ahorro inicial, aportaciones mensuales y un interés anual. El modelo aplica capitalización mensual y considera las aportaciones al final de cada mes; no predice rentabilidades reales.",
    faq: [
      {
        q: "¿Qué supone el interés compuesto mensual?",
        a: "La estimación divide el tipo anual entre doce y aplica el interés cada mes, antes de sumar la aportación mensual al final del periodo.",
      },
    ],
  },
  {
    path: "/politica-de-privacidad",
    title: "Política de privacidad | CalculaFácil",
    description:
      "Plantilla editable de privacidad de CalculaFácil. Completa y revisa los datos del titular y los tratamientos reales antes de publicar.",
    intro:
      "Esta página es una plantilla de trabajo. El titular debe completar los datos de responsable, finalidades, bases jurídicas, plazos y derechos según el funcionamiento real del sitio.",
  },
  {
    path: "/politica-de-cookies",
    title: "Política de cookies | CalculaFácil",
    description:
      "Plantilla editable de cookies y preferencias de privacidad. Revisa las tecnologías reales del sitio antes de publicar.",
    intro:
      "La preferencia actual se guarda en el almacenamiento local del navegador. No se cargan analítica ni anuncios de terceros; actualiza esta política si eso cambia.",
  },
  {
    path: "/aviso-legal",
    title: "Aviso legal | CalculaFácil",
    description:
      "Plantilla de aviso legal para CalculaFácil con campos pendientes para titular, NIF, domicilio, contacto, dominio y fechas.",
    intro:
      "Plantilla editable para España. Incorpora los datos reales del titular y las condiciones aplicables, y solicita una revisión antes de publicarla.",
  },
  {
    path: "/contacto",
    title: "Contacto | CalculaFácil",
    description:
      "Contacta con CalculaFácil. Valida tu mensaje y prepara un correo desde tu aplicación, sin enviar tus datos a un servidor.",
    intro:
      "El formulario valida tu nombre, correo y mensaje y prepara un borrador en tu aplicación de correo. Sustituye la dirección de ejemplo antes de publicar.",
  },
  {
    path: "/sobre-nosotros",
    title: "Sobre CalculaFácil | Calculadoras gratuitas",
    description:
      "Conoce CalculaFácil, un portal gratuito de herramientas prácticas que calcula directamente en tu navegador y no requiere registro.",
    intro:
      "CalculaFácil reúne calculadoras y conversores gratuitos para resolver dudas cotidianas con resultados claros, sin registro y desde el navegador.",
  },
];

const tools = pages.filter((page) =>
  [
    "/calculadora-porcentajes",
    "/calculadora-iva",
    "/calculadora-descuentos",
    "/calculadora-edad",
    "/regla-de-tres",
    "/dias-entre-fechas",
    "/convertir-kilometros-a-millas",
    "/convertir-kilos-a-libras",
    "/calculadora-propinas",
    "/calculadora-ahorro-mensual",
  ].includes(page.path),
);

function escapeHtml(value) {
  return value
    .replaceAll("&", "&amp;")
    .replaceAll("<", "&lt;")
    .replaceAll(">", "&gt;")
    .replaceAll('"', "&quot;")
    .replaceAll("'", "&#39;");
}

function absoluteUrl(route) {
  return `${siteUrl}${route === "/" ? "/" : route}`;
}

function linkList(currentPath) {
  return tools
    .filter((tool) => tool.path !== currentPath)
    .slice(0, 5)
    .map(
      (tool) =>
        `<li><a href="${tool.path}">${escapeHtml(tool.title.replace(" online gratis", ""))}</a></li>`,
    )
    .join("");
}

function fallbackContent(page) {
  const faq = page.faq?.length
    ? `<section><h2>Preguntas frecuentes</h2>${page.faq
        .map(
          (item) =>
            `<article><h3>${escapeHtml(item.q)}</h3><p>${escapeHtml(item.a)}</p></article>`,
        )
        .join("")}</section>`
    : "";
  const toolsLinks =
    page.path.startsWith("/politica-") ||
    ["/aviso-legal", "/contacto", "/sobre-nosotros"].includes(page.path)
      ? ""
      : `<nav aria-label="Calculadoras relacionadas"><h2>Más calculadoras</h2><ul>${linkList(page.path)}</ul></nav>`;
  const legalNotice = [
    "/politica-de-privacidad",
    "/politica-de-cookies",
    "/aviso-legal",
  ].includes(page.path)
    ? "<p><strong>Plantilla editable:</strong> completa y revisa los datos del titular antes de publicar.</p>"
    : "";
  return `<main class="seo-fallback"><h1>${escapeHtml(page.path === "/" ? "Todas tus calculadoras gratuitas en un solo lugar" : page.title.split(" | ")[0])}</h1><p>${escapeHtml(page.intro)}</p>${legalNotice}${toolsLinks}${faq}</main>`;
}

function structuredData(page) {
  const schemas = [
    {
      "@context": "https://schema.org",
      "@type": "WebSite",
      name: "CalculaFácil",
      url: absoluteUrl("/"),
      inLanguage: "es-ES",
    },
    {
      "@context": "https://schema.org",
      "@type": "WebApplication",
      name: "CalculaFácil",
      applicationCategory: "UtilitiesApplication",
      operatingSystem: "Any",
      description: page.description,
      url: absoluteUrl(page.path),
    },
  ];
  if (page.path !== "/") {
    schemas.push({
      "@context": "https://schema.org",
      "@type": "BreadcrumbList",
      itemListElement: [
        {
          "@type": "ListItem",
          position: 1,
          name: "Inicio",
          item: absoluteUrl("/"),
        },
        {
          "@type": "ListItem",
          position: 2,
          name: page.title.split(" | ")[0],
          item: absoluteUrl(page.path),
        },
      ],
    });
  }
  if (page.faq?.length) {
    schemas.push({
      "@context": "https://schema.org",
      "@type": "FAQPage",
      mainEntity: page.faq.map((item) => ({
        "@type": "Question",
        name: item.q,
        acceptedAnswer: { "@type": "Answer", text: item.a },
      })),
    });
  }
  return schemas
    .map(
      (schema) =>
        `<script type="application/ld+json" data-calculafacil-schema>${JSON.stringify(schema)}</script>`,
    )
    .join("\n");
}

function renderPage(shell, page) {
  const description = escapeHtml(page.description);
  const canonical = absoluteUrl(page.path);
  const title = escapeHtml(page.title);
  let html = shell
    .replace(/<html lang="[^"]*">/, '<html lang="es-ES">')
    .replace(/<title>[\s\S]*?<\/title>/, `<title>${title}</title>`)
    .replace(
      /<meta name="description" content="[^"]*"\s*\/>/,
      `<meta name="description" content="${description}" />`,
    )
    .replace(
      /<meta property="og:title" content="[^"]*"\s*\/>/,
      `<meta property="og:title" content="${title}" />`,
    )
    .replace(
      /<meta property="og:description" content="[^"]*"\s*\/>/,
      `<meta property="og:description" content="${description}" />`,
    )
    .replace(
      /<meta property="og:type" content="[^"]*"\s*\/>/,
      `<meta property="og:type" content="website" />\n    <meta property="og:url" content="${canonical}" />`,
    )
    .replace(
      /<meta name="twitter:title" content="[^"]*"\s*\/>/,
      `<meta name="twitter:title" content="${title}" />`,
    )
    .replace(
      /<meta name="twitter:description" content="[^"]*"\s*\/>/,
      `<meta name="twitter:description" content="${description}" />`,
    )
    .replace(
      "</head>",
      `<link rel="canonical" href="${canonical}" />\n    <style>.seo-fallback{max-width:760px;margin:40px auto;padding:0 22px;font:16px/1.7 system-ui,sans-serif;color:#203247}.seo-fallback h1,.seo-fallback h2,.seo-fallback h3{line-height:1.25;color:#193d5a}.seo-fallback a{color:#176899}.seo-fallback li{margin:.35rem 0}</style>\n    ${structuredData(page)}\n  </head>`,
    )
    .replace(
      '<div id="root"></div>',
      `<div id="root">${fallbackContent(page)}</div>`,
    );
  return html;
}

const shell = await readFile(path.join(publicDir, "index.html"), "utf8");
for (const page of pages) {
  const html = renderPage(shell, page);
  if (page.path === "/") {
    await writeFile(path.join(publicDir, "index.html"), html);
  } else {
    const routeDir = path.join(publicDir, page.path.slice(1));
    await mkdir(routeDir, { recursive: true });
    await writeFile(path.join(routeDir, "index.html"), html);
  }
}

const sitemap = `<?xml version="1.0" encoding="UTF-8"?>\n<urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">\n${pages
  .map(
    (page) =>
      `  <url><loc>${absoluteUrl(page.path)}</loc><changefreq>${page.path === "/" ? "weekly" : "monthly"}</changefreq><priority>${page.path === "/" ? "1.0" : tools.some((tool) => tool.path === page.path) ? "0.8" : "0.4"}</priority></url>`,
  )
  .join("\n")}\n</urlset>\n`;
await writeFile(path.join(publicDir, "sitemap.xml"), sitemap);
await writeFile(
  path.join(publicDir, "robots.txt"),
  `User-agent: *\nAllow: /\nSitemap: ${siteUrl}/sitemap.xml\n`,
);
